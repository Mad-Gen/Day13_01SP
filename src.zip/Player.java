import java.util.ArrayList;
import java.util.List;

/**
 * 遊ぶ人を表す「プレイヤー」クラスです。
 * @author M_Nukari
 *
 */
public abstract class Player {
	// プレイヤー名
	private String name;

	// 手札
	protected List<Card> listHand = new ArrayList<>();

	/**
	 * コンストラクタ
	 * @param name
	 */
	public Player(String name) {
		this.name = name;
	}

	/**
	 * プレイヤー名を取得
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * 手札を追加
	 * @param cards
	 */
	public void addHand(Card[] cards) {
		for(Card c : cards) {
			this.listHand.add(c);
		}
	}

	/**
	 * 手札を参照
	 * @return
	 */
	public Card[] getHand() {
		return listHand.toArray(new Card[0]);
	}

	/**
	 * 手札を捨てる
	 * abstractがついているのでサブクラス(継承したクラス)でメソッドの処理を実際にコーディングする必要があります。
	 * @return
	 */
	public abstract Card[] discard();

	/**
	 * 手札をすべて破棄
	 */
	public Card[] discardAll() {
		// リストを配列に変換するコードです。
		Card[] discard = this.listHand.toArray(new Card[0]);

		// 手札からカードを削除します。
		this.listHand.clear();

		return discard;
	}

	/**
	 * カードを表示
	 * @param info
	 * @param card
	 */
	public void showCard() {
		System.out.print(name + "\t: ");
		for(int i=0; i<listHand.size(); i++) {
			Card card = this.listHand.get(i);
			System.out.print(card.toString() + "{" + (i+1) + "}");
			if(i < listHand.size()-1) {
				System.out.print(", ");
			}
		}
	}
}
