import lib.Input;

/**
 * ポーカー(ドローポーカー)のゲームクラス
 * @author M_Nukari
 *
 */
public class DrawPokerGame {
	
	private Deck deck = new Deck();
	private Player player1 = new HumanPlayer("P1");
	private Player player2 = new WeekAIPlayer("P2(AI)");
	
	/**
	 * コンストラクタ
	 */
	DrawPokerGame(){
	}
	
	/**
	 * ゲームを実行
	 */
	public void execute() {
		// 山札をシャッフル
		this.deck.shuffle();
		
		//　人間が勝利した回数
		int victory = 0;
		
		// 指定回数対戦
		for(int i=0; i<5; i++) {
			
			// Player1がカードをデッキから引きます。
			Card[] drawcards1 = this.deck.draw(5);
			this.player1.addHand(drawcards1);
			this.player1.showCard();
			this.showPokerHand(player1);
			
			// Player2がカードをデッキから引きます。
			Card[] drawcards2 = this.deck.draw(5);
			this.player2.addHand(drawcards2);
			this.player2.showCard();
			this.showPokerHand(player2);
			
			// Player1がカードを入れ替えます。
			Card[] discards1 = this.player1.discard();
			this.deck.addDiscard(discards1); // 手札を山に捨てます。
			
			// Player2がカードを入れ替えます。
			Card[] discards2 = this.player2.discard();
			this.deck.addDiscard(discards2); // 手札を山に捨てます。
			
			// Player1が捨てた分のカードを補充します。
			drawcards1 = this.deck.draw(discards1.length);
			this.player1.addHand(drawcards1);
			this.player1.showCard();
			this.showPokerHand(player1);
			
			// Player2が捨てた分のカードを補充します。
			drawcards2 = this.deck.draw(discards2.length);
			this.player2.addHand(drawcards2);
			this.player2.showCard();
			this.showPokerHand(player2);
			
			// 勝負を判定します。
			if(this.judge(player1, player2)) {
				victory++;
			}
			
			// 手札を山札に戻し、次の対戦の準備を行います。
			Input.getString((i+1) + " 回目終了。次のゲームへ...");
			System.out.println();
			
			// Player1のカードをすべて山に捨てます。
			discards1 = this.player1.discardAll();
			this.deck.addDiscard(discards1);
			
			// Player2のカードをすべて山に捨てます。
			discards2 = this.player2.discardAll();
			this.deck.addDiscard(discards2);
		}
		
		// 結果発表
		System.out.println("あなたは " + victory + " 回 AIに勝利しました。");
		if(4 < victory) {
			System.out.println("さすがのポーカーフェースですね(^^♪");
		}else if(2 < victory) {
			System.out.println("まずまずの強さですね(´・ω・)");
		}else if(1 < victory) {
			System.out.println("もうすこし頑張りましょう(-_-)/~~~ピシー!ピシー!");
		}else {
			System.out.println("ダメダメですね( ˘•ω•˘ )");
		}
	}
	
	/**
	 * 役を表示します。
	 * @param p
	 */
	private void showPokerHand(Player p) {
		Card[] hand = p.getHand();
		System.out.print("\t");
		System.out.print("[" + DrawPokerHandJudge.getHandName(DrawPokerHandJudge.checkHand(hand)) + "]");
		System.out.println();
	}
	
	/**
	 * 勝敗を判定します。
	 * @param p1
	 * @param p2
	 */
	private boolean judge(Player p1, Player p2) {
		int score1 = DrawPokerHandJudge.checkHand(p1.getHand());
		int score2 = DrawPokerHandJudge.checkHand(p2.getHand());
		
		if (score1 > score2) {
			System.out.println("☆ " + p1.getName() + " の勝ち");
			return true;
		} else if (score1 < score2) {
			System.out.println("☆ " + p2.getName() + " の勝ち");
		} else {
			score1 = DrawPokerHandJudge.getkLargestNumberScore(p1.getHand());
			score2 = DrawPokerHandJudge.getkLargestNumberScore(p2.getHand());
			if (score1 > score2) {
				System.out.println("☆ " + p1.getName() + " の勝ち");
				return true;
			} else if (score2 < score1) {
				System.out.println("☆ " + p2.getName() + " の勝ち");
			} else {
				System.out.println("ドローゲーム");
			}
		}
			
		return false;
	}
}
