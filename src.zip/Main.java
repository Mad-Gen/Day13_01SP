/**
 * メインクラス
 * @author M_Nukari
 *
 */
public class Main {

	/**
	 * メインクラス
	 * @param args
	 */
	public static void main(String[] args) {
		// ドローポーカーゲームクラスをインスタンス化し、ゲームをスタートします。
		DrawPokerGame game = new DrawPokerGame();
		game.execute();
	}
}
